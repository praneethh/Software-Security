/**
 * 
 */
/**
 * @author rbh
 *
 */
package boss.data.entities;